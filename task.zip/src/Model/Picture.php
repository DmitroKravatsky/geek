<?php
/**
 * Created by PhpStorm.
 * User: dima
 * Date: 13.08.17
 * Time: 19:59
 */

namespace src\Model;


use application\DB;

class Picture

{
    public $fileExt = null;
    public $valid_types =  array("gif","jpg", "png", "jpeg", "GIF", "JPG", "PNG", "JPEG");

    public function checkType()
    {
        if (!empty($_FILES))
        {
            $ext = substr($_FILES['picture']['name'], 1 + strrpos($_FILES['picture']['name'], "."));
            $validExts =  array("gif","jpg", "png", "jpeg", "GIF", "JPG", "PNG", "JPEG");
            if (in_array($ext,$validExts)){
                $this->fileExt = $ext;

                return $this->fileExt;
            }
            return false;
        }
    }

    public function createPicture ($input,$w,$h,$output) {
        $q = 100;  // качество jpeg по умолчанию

        $func = "imagecreatefrom".$this->fileExt;
        //var_dump($func);exit;
        $src = $func($input);
        $w_src = imagesx($src);
        $h_src= imagesy($src);

        $resizeW = $w_src/$w;
        $resizeH = $w_src/$h;
        $w_dest = round($w_src/$resizeW);
        $h_dest = round($h_src/$resizeH);

        $dest = imagecreatetruecolor($w_dest,$h_dest);
        imagecopyresized($dest, $src, 0, 0, 0, 0, $w_dest, $h_dest, $w_src, $h_src);

        $f = "image".$this->fileExt;
        $f($dest,$output,$q);
        imagedestroy($dest);
        imagedestroy($src);
    }


}