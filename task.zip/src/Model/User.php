<?php
/**
 * Created by PhpStorm.
 * User: artem
 * Date: 11.08.17
 * Time: 23:17
 */

namespace src\Model;



use application\DB;

class User
{
    public $dbName = 'user';

    public function login($data)
    {

        $db = DB::getInstance();
        $condition['login'] =  $data['name'];
        //var_dump($condition); exit;
        $admin = $db->getOneBy('user',$condition);
        return ($admin) ? $admin : null;
    }

}