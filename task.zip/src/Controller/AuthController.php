<?php
/**
 * Created by PhpStorm.
 * User: dima
 * Date: 13.08.17
 * Time: 21:56
 */

namespace src\Controller;


use application\Controller;
use application\Url;
use src\Model\User;

class AuthController extends Controller
{
    public function actionLogin()
    {

        if (!empty($_POST)){
            $fields=[
                'name' => $_POST['userName'],
                'password' => $_POST['userPassword']];
            $user = new User();

            $login = $user->login($fields);
            //var_dump($login); exit;
            if (!is_null($login))
                {
                    if ($login[0]['login'] == $fields['name'] and $login[0]['password'] == $fields['password'] ){
                        session_start();
                        $_SESSION['name'] = $login[0]['login'];
                        return $this->redirect(Url::toRoute('admin/index'));
                    }
                }else   return $this->render('login', ['warning' => 'Login or password is wrong'

            ]);
        } else   return $this->render('login', [

            ]);
    }

    public function actionLogout()
    {
        if (isset($_SESSION['name'])){
            unset($_SESSION['name']);
            session_destroy();
        }

        return $this->redirect(Url::toRoute('site/index'));
    }
}